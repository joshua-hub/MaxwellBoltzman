/*******************************************************************************
  PHYS3071 (and PHYS7073) Lecture Week 9 Baumgardt 0123456

  Program maxwell-boltzmann (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.

  About: This program integrates the Maxwell-Boltzmann distribution
         up to infinity using the midpoint method 

  Compile: gcc -Wall -lm as09_mb2.c -o as09_mb2

  Input: The step size for the integration 

  Output: The value of the integral
***********************80*character*limit*good*for* a2ps***********************/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#define PI 3.1415926536

#define ALPHA 4.0/sqrt(PI)

int main() {
 double sum,t,tmid,dt; 

 printf("Input step size delta t: "); 
 scanf("%lf",&dt);

 sum = 0.0;   // Start values for t and the integral
 t=0.0;   

 do {
   tmid = t+dt/2.0;    // Evaluate the midpoint of the step
   if (tmid != 0.0) sum += exp(-pow(1.0/tmid-1.0,2.0))*pow(1.0/(tmid*tmid)-1.0/tmid,2.0)*dt;
   t += dt;
 } while (t<1.0);

 printf("Value of the integral is: %15.10lf\n",ALPHA*sum);

 printf("Program finished OK !\n");
 exit(0);
}

