/*******************************************************************************
  PHYS3071 (and PHYS7073) Lecture Week 9 Baumgardt 0123456
 
  Program maxwell-boltzmann (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.
 
  About: This program integrates the Maxwell-Boltzmann distribution  
         using the Trapezoidal rule
 
  Compile: gcc -Wall -lm as09_mb1.c -o as09_mb1
 
  Input: The highest velocity up to which the distribution is to be integrated 
         and the accuracy with which the integral should be determined
 
  Output: The value of the integral
***********************80*character*limit*good*for* a2ps***********************/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#define PI 3.1415927

#define ALPHA 4.0/sqrt(PI)

int main() {
 double vmax,e,deltav,sum,vi,weight;
 double err,errmax;
 int i,nstep=2;

 printf("Input highest velocity: "); 
 scanf("%lf",&vmax);

 printf("Input desired accuracy: "); 
 scanf("%lf",&e);

// Loop over different stepsizes 
 do {
   sum = 0.0;
   errmax = 0.0;
  
   deltav = vmax/(1.0*nstep);

// Trapezoidal integration
   for (i=0;i<=nstep;i++) {
     if (i==0 || i==nstep)     // Assign weights 
        weight=1.0;
     else 
        weight=2.0;
     vi = 0.0+vmax/(1.0*nstep)*i;
     sum += weight*ALPHA*exp(-vi*vi)*vi*vi;
     err = ALPHA*exp(-vi*vi)*(-10.0*vi*vi+4.0*vi*vi*vi*vi+2.0);
     if (fabs(err)>errmax) errmax=fabs(err);
   }
   sum    *= deltav/2.0;
   errmax *= vmax*vmax*vmax/(12.0*pow(nstep,2.0));  // Evaluate upper bound for integration error

   printf("%5i %15.10lf %15.10lf\n",nstep,sum,errmax);
   nstep *= 2;           // Double stepsize
 } while (errmax>e);     // Check if integration was accurate enough 

 printf("Program finished OK !\n");
 exit(0);
}

